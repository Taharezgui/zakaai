import React from "react";
import { Card, CardContent } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Textarea } from "../components/ui/textarea";
import { Sparkles } from "lucide-react";

export default function Home() {
  return (
    <main className="p-6 max-w-4xl mx-auto">
      <header className="text-center space-y-4 mb-10">
        <h1 className="text-4xl font-bold text-gray-800">ذكائي - أدوات ذكاء صناعي مجانية</h1>
        <p className="text-gray-600 text-lg">
          حلّق بإنتاجيتك مع أدوات ذكية باللغة العربية تساعدك في الكتابة، التلخيص، تحويل الصوت، وتوليد الصور.
        </p>
      </header>

      <section className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold mb-2">✍️ الكاتب الذكي</h2>
            <Textarea placeholder="اكتب موضوعك أو فكرتك..." className="mb-2" />
            <Button className="w-full">إنشاء نص</Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold mb-2">🧠 الملخص</h2>
            <Textarea placeholder="ألصق النص الطويل هنا..." className="mb-2" />
            <Button className="w-full">تلخيص</Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold mb-2">🎨 الرسام الذكي</h2>
            <Input placeholder="صف الصورة التي تتخيلها..." className="mb-2" />
            <Button className="w-full">إنشاء صورة</Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold mb-2">🎧 تحويل الصوت إلى نص</h2>
            <Input type="file" accept="audio/*" className="mb-2" />
            <Button className="w-full">تفريغ</Button>
          </CardContent>
        </Card>
      </section>

      <footer className="text-center mt-12 text-sm text-gray-500">
        جميع الحقوق محفوظة © 2025 ذكائي | Powered by OpenAI APIs
      </footer>
    </main>
  );
}
