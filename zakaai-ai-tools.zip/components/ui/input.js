export const Input = (props) => <div {...props} />;
